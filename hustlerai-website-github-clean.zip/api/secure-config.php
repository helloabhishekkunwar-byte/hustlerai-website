<?php
/**
 * Secure Razorpay configuration loader.
 *
 * Credentials are read from environment variables first, then from a PHP
 * config file OUTSIDE the public_html directory:
 *   ../private/razorpay-config.php
 *
 * The private file must return:
 * [
 *   'key_id' => 'rzp_test_...',
 *   'key_secret' => '...',
 *   'amount' => 29700,
 *   'currency' => 'INR',
 * ];
 */
$privateConfigPath = dirname(__DIR__, 2) . '/private/razorpay-config.php';
$config = [];

if (is_file($privateConfigPath)) {
    $loaded = require $privateConfigPath;
    if (is_array($loaded)) {
        $config = $loaded;
    }
}

$keyId = getenv('HUSTLERAI_RAZORPAY_KEY_ID') ?: ($config['key_id'] ?? '');
$keySecret = getenv('HUSTLERAI_RAZORPAY_KEY_SECRET') ?: ($config['key_secret'] ?? '');

if ($keyId === '' || $keySecret === '') {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'Razorpay server credentials are not configured.']);
    exit;
}

return [
    'key_id' => $keyId,
    'key_secret' => $keySecret,
    'amount' => 29700,
    'currency' => 'INR',
];
