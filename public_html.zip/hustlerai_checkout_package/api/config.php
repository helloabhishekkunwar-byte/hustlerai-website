<?php
// Add your Razorpay LIVE or TEST credentials here. Never share Key Secret.
return [
  'key_id' => 'YOUR_RAZORPAY_KEY_ID',
  'key_secret' => 'YOUR_RAZORPAY_KEY_SECRET',
  'amount' => 29700, // ₹297 in paise. Do not accept amount from browser.
  'currency' => 'INR',
];
