<?php
// Add your Razorpay LIVE or TEST credentials here. Never share Key Secret.
return [
  'key_id' => 'rzp_test_TuuHbEEZV2Gu88',
  'key_secret' => 'YOUR_TEST_KEY_SECRET',
  'amount' => 29700, // ₹297 in paise. Do not accept amount from browser.
  'currency' => 'INR',
];
