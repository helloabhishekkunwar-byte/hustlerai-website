HUSTLERAI CUSTOM RAZORPAY CHECKOUT - INSTALL GUIDE

WHAT THIS PACKAGE DOES
- Adds a branded customer-details checkout page (₹297 fixed on server).
- Opens Razorpay Standard Checkout after the customer submits details.
- Verifies the Razorpay signature and checks payment status is captured before showing success.
- Uses the HustlerAI logo supplied in this chat.

BEFORE INSTALLING
1. In Hostinger hPanel, open Websites > Dashboard next to hustlerai.in.
2. Open Hosting plan > Plan Details and note the plan name. Hostinger's guide:
   https://support.hostinger.com/en/articles/1583276-how-to-find-the-details-of-your-hosting-plan
3. This package requires a PHP-enabled Web/Cloud hosting environment with PHP cURL and HTTPS. If your site is only on Hostinger Website Builder, this PHP package is not the right deployment method.
4. Back up the existing public_html files before replacing/editing anything.

UPLOAD
1. Extract this ZIP on your computer.
2. In Hostinger hPanel > Files > File Manager, open public_html.
3. Upload checkout.php and payment-success.php into public_html.
4. Upload the assets folder into public_html (merge if it already exists; do not delete existing assets).
5. Upload the api folder into public_html. It contains .htaccess to block direct web access to config.php.
6. Open public_html/api/config.php in File Manager and replace:
   YOUR_RAZORPAY_KEY_ID
   YOUR_RAZORPAY_KEY_SECRET
   with your Razorpay API credentials. Keep the Key Secret private. Never paste it into HTML/JS or send it in chat.

RAZORPAY KEYS
1. Razorpay Dashboard > Account & Settings > API Keys.
2. First use Test Mode keys for testing. Do not use Live keys until test flow works.
3. For live payments, generate Live Mode keys and put them in api/config.php.

CONNECT WEBSITE BUTTONS
Your current HTML has a script near the bottom that sets CHECKOUT_URL for all .cta-btn buttons.
Change only this line:
  const CHECKOUT_URL = 'https://rzp.io/rzp/iPoz6me';
or if it is blank, set it to:
  const CHECKOUT_URL = 'checkout.php';
Keep the surrounding script unchanged. Save the existing homepage file as it was (usually index.html).

TEST BEFORE GOING LIVE
1. Open https://hustlerai.in/checkout.php
2. Submit valid test customer details.
3. Complete a Razorpay Test Mode payment using Razorpay's test payment methods.
4. Confirm that the success page appears only after the server verifies the payment as captured.
5. Check Razorpay Dashboard > Transactions > Payments.
6. Only after successful testing, switch config.php to Live Mode keys.

IMPORTANT
- The price is fixed server-side at ₹297 (29700 paise); do not change it in browser JavaScript.
- This starter package does not save customer leads in a database or automatically send workshop access emails/WhatsApp messages. Add those separately if needed.
- Razorpay payment methods shown depend on your account, currency, customer/device and Razorpay configuration; do not promise every method will always appear.
- The current checkout page has a 30-day guarantee note because your existing sales page advertises a 30-day refund policy. Ensure your actual refund terms support this statement.
- If PHP cURL is disabled, ask Hostinger support to enable it.
